package mp.rage.launcher.streamer;

import org.slf4j.Logger;

public class StreamerEvents {
    private static final Logger log = org.slf4j.LoggerFactory.getLogger(StreamerEvents.class);

    private StreamerEvents() { }

    static void onPlayerStreamIn(int playerId, int forPlayerId) {

    }

    static void onPlayerStreamOut(int playerId, int forPlayerId) {

    }
}
