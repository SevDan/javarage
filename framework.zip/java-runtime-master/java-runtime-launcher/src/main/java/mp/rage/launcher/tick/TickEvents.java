package mp.rage.launcher.tick;

import org.slf4j.Logger;

public class TickEvents {
    private static final Logger log = org.slf4j.LoggerFactory.getLogger(TickEvents.class);

    private static final int defaultMachineId = 1;

    private TickEvents() { }

    static void onTick() {

    }
}
