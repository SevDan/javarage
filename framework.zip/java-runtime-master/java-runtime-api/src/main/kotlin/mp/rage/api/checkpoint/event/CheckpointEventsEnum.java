package mp.rage.api.checkpoint.event;

public enum CheckpointEventsEnum {
    CheckpointCreatedEvent,
    CheckpointDestroyedEvent,
    PlayerEnterCheckpointEvent,
    PlayerExitCheckpointEvent
}
