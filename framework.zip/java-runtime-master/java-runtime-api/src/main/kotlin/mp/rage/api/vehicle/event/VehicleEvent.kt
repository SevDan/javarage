package mp.rage.api.vehicle.event

import mp.rage.api.event.AbstractEvent
import mp.rage.api.vehicle.Vehicle

abstract class VehicleEvent(vehicle: Vehicle) : AbstractEvent()