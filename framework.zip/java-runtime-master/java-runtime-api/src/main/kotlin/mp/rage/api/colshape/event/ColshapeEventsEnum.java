package mp.rage.api.colshape.event;

public enum ColshapeEventsEnum {
    ColshapeCreatedEvent,
    ColshapeDestroyedEvent,
    PlayerEnterColshapeEvent,
    PlayerExitColshapeExit
}
