package mp.rage.api.blip.event

import mp.rage.api.blip.Blip
import mp.rage.api.event.AbstractEvent

abstract class BlipEvent : AbstractEvent()