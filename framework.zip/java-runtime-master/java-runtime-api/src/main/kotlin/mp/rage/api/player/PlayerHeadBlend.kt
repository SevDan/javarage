package mp.rage.api.player

data class PlayerHeadBlend(
        val shape: Int,
        val skin: Int,
        val shapeMix: Float,
        val skinMix: Float,
        val thirdMix: Float
)