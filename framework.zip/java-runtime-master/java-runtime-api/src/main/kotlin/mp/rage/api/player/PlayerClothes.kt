package mp.rage.api.player

class PlayerClothes {
    
}