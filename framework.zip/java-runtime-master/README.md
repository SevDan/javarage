# Rage Multiplayer Java Runtime

Build: [![CircleCI](https://circleci.com/gh/ragemp-java/java-runtime/tree/master.svg?style=svg)](https://circleci.com/gh/ragemp-java/java-runtime/tree/master)

